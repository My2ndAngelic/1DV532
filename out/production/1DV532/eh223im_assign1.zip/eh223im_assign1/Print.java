package eh223im_assign1;

public class Print {

    public static void main(String[] args) {
	    System.out.println("Write once, run everywhere!");

	    System.out.println();

        System.out.println("Write\nonce\nrun\neverywhere");

        System.out.println();

        System.out.println("*******************************\n" +
                           "* Write once, run everywhere! *\n"+
                           "*******************************\n" );
    }
}
